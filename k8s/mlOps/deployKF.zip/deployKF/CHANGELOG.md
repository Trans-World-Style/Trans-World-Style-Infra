# Changelog

The changelog for deployKF is found on the deployKF website:

1. [Main Changelog](https://www.deploykf.org/releases/changelog-deploykf/)
2. [Full Changelog (including pre-releases)](https://www.deploykf.org/releases/full-changelog-deploykf/)

Both changelogs are automatically generated from the [GitHub Releases](https://github.com/deployKF/deployKF/releases).
